//
//  Dynamic.swift
//  Tech Bay
//
//  Created by Faizan Ali  on 2020/10/15.
//

class Dynamic<T> {
    typealias Listener = (T) -> ()
    var listeners = Array<Listener>()
    var listnerIds = Array<String>()
    
    var allListener = Dictionary<String, Listener>()
    
    func bind(_ listener: @escaping Listener) {
        bind(listener, id: "none")
    }
    
    func bind(_ listener: @escaping Listener, id : String = "") {
        let key = id.lowercased()
        allListener[key] = listener
   }
    
    func bindAndFire(_ listener: @escaping Listener) {
        bindAndFire(listener, id: "")
    }
    
    func bindAndFire(_ listener: @escaping Listener, id: String = "") {
        
        allListener[id] = listener
        for listner in allListener.values{
            listner(value)
        }
    }
    
    var value: T {
        didSet {
            for listner in allListener.values{
                listner(value)
            }
        }
    }
    
    init(_ v: T) {
        value = v
    }
    
    func removeListener(id: String){
        let index = allListener.firstIndex { (li) -> Bool in
            return li.key == id.lowercased()
        }
        
        if(index != nil){
            allListener.remove(at: index!)
        }
        
    }
}
