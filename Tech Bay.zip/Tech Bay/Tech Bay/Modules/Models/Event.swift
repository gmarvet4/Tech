//
//  AllEvent.swift
//  Tech Bay
//
//  Created by Faizan Ali  on 2020/10/15.
//

import Foundation
import UIKit

struct AllEvent {
    
    var name: String
    var image: UIImage
}

struct PopularEvent {
    
    var title: String
    var image: UIImage
    var dateStr: String
    var address: String
}
