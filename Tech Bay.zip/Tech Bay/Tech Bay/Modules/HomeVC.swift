//
//  HomeVC.swift
//  Tech Bay
//
//  Created by Faizan Ali  on 2020/10/15.
//

import UIKit

class HomeVC: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var theTableView: UITableView!
    var viewModel: HomeVM!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        registerXib()
        self.viewModel = HomeVM()
        bindUI()
    }
    
    func bindUI(){
        
        viewModel.dataChanged.bindAndFire { (data) in
            self.theTableView.reloadData()
        }
    }
    
    private func registerXib(){
        
        let nib0 = UINib(nibName: HomeCellXibType.header.rawValue, bundle: nil)
        self.theTableView.register(nib0, forCellReuseIdentifier: HomeCellXibType.header.rawValue)
        
        let nib1 = UINib(nibName: HomeCellXibType.allEvent.rawValue, bundle: nil)
        self.theTableView.register(nib1, forCellReuseIdentifier: HomeCellXibType.allEvent.rawValue)
        
        let nib2 = UINib(nibName: HomeCellXibType.popularEvent.rawValue, bundle: nil)
        self.theTableView.register(nib2, forCellReuseIdentifier: HomeCellXibType.popularEvent.rawValue)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let sectionKey = viewModel.SECTION
        return viewModel.data[sectionKey]!.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let sectionKey = viewModel.SECTION
        let cellId = (viewModel.data[sectionKey]![indexPath.row] as! HomeCellXib).xib.rawValue
        let cell = tableView.dequeueReusableCell(withIdentifier: cellId, for: indexPath) as! HomeParentCell
        
        cell.viewModel = viewModel
        cell.parentViewController = self
        
        if indexPath.row > 1{
            cell.popularEvent = viewModel.popularEvents[indexPath.row - 2]
        }
        cell.setupUI()
        
        return cell
    }
}

