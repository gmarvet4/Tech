//
//  HomeVM.swift
//  Tech Bay
//
//  Created by Faizan Ali  on 2020/10/15.
//

import Foundation
import UIKit

class HomeVM {
    
    let SECTION = "Section"
    var data = Dictionary<String, Array<Any>>()
    
    var dataChanged: Dynamic <Bool> = Dynamic(false)
    
    var allEvents: Array<AllEvent> = Array<AllEvent>()
    var popularEvents: Array<PopularEvent> = Array<PopularEvent>()
    
    init() {
        fetchData()
        prepareData()
    }
    
    internal func prepareData(){
        
        data.removeAll()
        data[SECTION] = Array<HomeCellXib>()
        
        data[SECTION]!.append(HomeCellFactory.headerCell)
        data[SECTION]!.append(HomeCellFactory.allEventCell)
        data[SECTION]!.append(HomeCellFactory.popularEventCell)
        data[SECTION]!.append(HomeCellFactory.popularEventCell)
        data[SECTION]!.append(HomeCellFactory.popularEventCell)
        
    }
    
    func fetchData() {
        
        //We will fetch data if it will come from server. Now its manually filled.
        
        //All Events.
        let e1 = AllEvent(name: "Concert", image: UIImage.init(named: "star")!)
        allEvents.append(e1)
        let e2 = AllEvent(name: "Sports", image: UIImage.init(named: "ping-pong")!)
        allEvents.append(e2)
        let e3 = AllEvent(name: "Education", image: UIImage.init(named: "college-graduation")!)
        allEvents.append(e3)
        allEvents.append(e1)
        allEvents.append(e2)
        allEvents.append(e3)
        
        
        
        //Popular Events.
        let pe1 = PopularEvent(title: "Sports Meet in Galaxy Field", image: UIImage.init(named: "Image 51")!, dateStr: "Jan 12 2019", address: "Green field 42 Faridabad")
        popularEvents.append(pe1)
        
        let pe2 = PopularEvent(title: "Art and Meet in Street Plaza", image: UIImage.init(named: "Image 49")!, dateStr: "Feb 22 2019", address: "Galaxy field 23 Lahore")
        popularEvents.append(pe2)
        
        let pe3 = PopularEvent(title: "Youth Music in Galleria", image: UIImage.init(named: "Image 54")!, dateStr: "Mar 15 2019", address: "Green Park 78 Faridabad")
        popularEvents.append(pe3)
        
        //Fetch Entries...
        
        NetworkManager.shared.entriesRepository.getEntries { (entries, error) in
            
            if let error = error{
                print("Something went wrong. Error: \(error.localizedDescription)")
                
            } else if entries?.effectEntries != nil{
               
                entries!.effectEntries!.forEach({ (e) in
                    print("Entry: \(e)\n")
                })
                
                
            } else{
                print("Something went wrong!")
            }
            
        }

    }
}
