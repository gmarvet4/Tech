//
//  HomeCellXib.swift
//  Tech Bay
//
//  Created by Faizan Ali  on 2020/10/15.
//

import Foundation
import UIKit

class HomeCellXib {
    let xib : HomeCellXibType
    let minimumHeight : CGFloat
    var data : Any? = nil
    
    init(xbId: HomeCellXibType, height: CGFloat){
        self.xib = xbId
        self.minimumHeight = height
    }
}

enum HomeCellXibType : String{
    case header = "HomeHeaderCell"
    case allEvent = "HomeAllEventsCell"
    case popularEvent = "HomePopularEventsCell"

}

class HomeCellFactory {
    
    static let headerCell = HomeCellXib(xbId: HomeCellXibType.header, height: CGFloat(200))
    static let allEventCell = HomeCellXib(xbId: HomeCellXibType.allEvent, height: CGFloat(100))
    static let popularEventCell = HomeCellXib(xbId: HomeCellXibType.popularEvent, height: CGFloat(100))
    
}
