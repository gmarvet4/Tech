//
//  HomeParentCell.swift
//  Tech Bay
//
//  Created by Faizan Ali  on 2020/10/15.
//

import Foundation
import UIKit

class HomeParentCell : UITableViewCell {
    
    var viewModel : HomeVM!
    var parentViewController : HomeVC!
    var popularEvent: PopularEvent?
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.selectionStyle = .none
        
        if(viewModel != nil) {
            setupUI()
        }
    }
    
    func setupUI(){
        setupTheme()
    }
    
    func setupTheme(){
        
    }

}
