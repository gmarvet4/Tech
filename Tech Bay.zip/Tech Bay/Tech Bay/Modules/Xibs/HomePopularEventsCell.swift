//
//  HomePopularEventsCell.swift
//  Tech Bay
//
//  Created by Faizan Ali  on 2020/10/15.
//

import UIKit

class HomePopularEventsCell: HomeParentCell {
   
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var lblDate: UILabel!
    @IBOutlet weak var lblAddress: UILabel!
    @IBOutlet weak var lblTitle: UILabel!
    
    override func setupUI() {
        super.setupUI()
        
        lblTitle.text = popularEvent?.title
        lblDate.text = popularEvent?.dateStr
        lblAddress.text = popularEvent?.address
        imgView.image = popularEvent?.image
    }
    
    override func setupTheme() {
        super.setupTheme()
        
    }

    
}
