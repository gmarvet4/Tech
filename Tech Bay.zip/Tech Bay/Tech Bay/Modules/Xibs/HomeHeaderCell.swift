//
//  HomeHeaderCell.swift
//  Tech Bay
//
//  Created by Faizan Ali  on 2020/10/15.
//

import UIKit

class HomeHeaderCell: HomeParentCell {

    override func setupUI() {
        super.setupUI()
        
    }
    
    override func setupTheme() {
        super.setupTheme()
        
    }
    
}
