//
//  HomeAllEventsCell.swift
//  Tech Bay
//
//  Created by Faizan Ali  on 2020/10/15.
//

import UIKit

class HomeAllEventsCell: HomeParentCell, UICollectionViewDelegate, UICollectionViewDataSource {
    
    @IBOutlet weak var theCollectionView: UICollectionView!
    
    override func setupUI() {
        super.setupUI()
        registerXib()
        theCollectionView.reloadData()
    }
    
    func registerXib() {
        
        let nib = UINib(nibName: "HomeAllEventsCollectionCell", bundle: nil)
        self.theCollectionView.register(nib, forCellWithReuseIdentifier: "HomeAllEventsCollectionCell")
    }
    
    override func setupTheme() {
        super.setupTheme()
        
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return viewModel.allEvents.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "HomeAllEventsCollectionCell", for: indexPath) as! HomeAllEventsCollectionCell
        
        cell.setupUI(name: viewModel.allEvents[indexPath.row].name, img: viewModel.allEvents[indexPath.row].image)
        return cell
    }
    
}
