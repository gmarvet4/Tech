//
//  HomeAllEventsCollectionCell.swift
//  Tech Bay
//
//  Created by Faizan Ali  on 2020/10/15.
//

import UIKit

class HomeAllEventsCollectionCell: UICollectionViewCell {
    
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var imgView: UIImageView!
    
    func setupUI(name: String, img: UIImage) {
        
        self.lblName.text = name
        self.imgView.image = img
    }

}
