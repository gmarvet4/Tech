//
//  Login.swift
//  Tech Bay
//
//  Created by Faizan Ali  on 2020/10/15.
//

import Foundation

struct EntriesResponse: Decodable {
   
    let effectEntries: [effectEntry]?
    
    enum CodingKeys: String, CodingKey {
        case effectEntries = "effect_entries"
    }
}

struct effectEntry: Decodable {
    let effect: String?
    let language: entriesLanguage?
    let shortEffect: String?
    
    
    enum CodingKeys: String, CodingKey {
        case effect
        case language
        case shortEffect = "short_effect"
    }
}

struct entriesLanguage: Decodable {
    let name: String?
    let url: String?
    
    
    enum CodingKeys: String, CodingKey {
        case name
        case url
    }
}
