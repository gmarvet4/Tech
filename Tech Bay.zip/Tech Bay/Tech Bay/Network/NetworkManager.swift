//
//  NetworkManager.swift
//  Tech Bay
//
//  Created by Faizan Ali  on 2020/10/15.
//

import Foundation

class NetworkManager{
    
    static let shared: NetworkManager = NetworkManager()
    
   private init() {}
    
    var entriesRepository: EntriesRepository = EntriesRepository()
}
