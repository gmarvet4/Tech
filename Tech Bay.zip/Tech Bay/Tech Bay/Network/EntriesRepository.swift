//
//  EntriesRepository.swift
//  Tech Bay
//
//  Created by Faizan Ali  on 2020/10/15.
//

import Foundation

import Alamofire

class EntriesRepository {
    
    func getEntries(block: @escaping (EntriesResponse?, Error?) -> Void){
        
        let url = "https://pokeapi.co/api/v2/ability/34/"
        
        AF.request(url, method: .get).validate(statusCode: 200..<300).validate(contentType: ["application/json"]).responseDecodable(of: EntriesResponse.self) { (response) in
            
            switch response.result {
            case .success:
                
                guard let entriesResponse = response.value else{
                    block(nil, nil)
                    return
                }
                block(entriesResponse, nil)
            case let .failure(error):
                block(nil, error)
            }
        }
    }
}
